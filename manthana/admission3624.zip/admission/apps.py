from django.apps import AppConfig


class LoginAppConfig(AppConfig):
    name = 'admission'
