Sansation - freeware font

Version 1.2
___________

This font is freeware for personal and commercial use.
Feel free to distribute this font. 
You may but this font on CDs, websites,... with the following restrictions:

	-Editing is only allowed for personal use,
	 don�t distribute an edited version of this font!
	-Do not rename this font!
	-Do not sell this font!
	-Do not handle it as your own work!
	-Do not pass the font without this textfile!
	-Make sure you have downloaded the latest update from www.dafont.com for best optical results.

I hope you enjoy this font.
If you have further questions, please contact me.
_________________________________________________

berndmontag@klausmontag.de
Bernd Montag � 2009 - All Rights Reserved
_________________________________________
_________________________________________

